import React from 'react';
import { Upload, ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="pt-32 pb-20 relative overflow-hidden">
      {/* Background grid effect */}
      <div className="absolute inset-0 z-0 opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(#00C8FF_1px,transparent_1px)] [background-size:40px_40px]"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
            Transform Your Trading with <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-blue to-accent-purple">Advanced Analytics</span>
          </h1>
          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
            Upload your trade data and gain powerful insights into your performance, mistakes, and patterns to make data-driven decisions.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="group w-full sm:w-auto bg-accent-blue hover:bg-accent-blue/90 text-gray-900 font-medium px-8 py-4 rounded-lg transition flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(0,200,255,0.5)]">
              <Upload size={20} />
              <span>Upload Your Trades</span>
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
            <button className="w-full sm:w-auto bg-transparent border border-gray-700 hover:border-gray-500 text-white px-8 py-4 rounded-lg transition">
              Watch Demo
            </button>
          </div>
          
          <div className="mt-16 flex flex-wrap items-center justify-center gap-8 opacity-70">
            <span className="text-sm uppercase tracking-widest">Trusted by traders from</span>
            <div className="flex flex-wrap justify-center gap-8">
              <span className="text-gray-400 font-medium">TradingView</span>
              <span className="text-gray-400 font-medium">MetaTrader</span>
              <span className="text-gray-400 font-medium">NinjaTrader</span>
              <span className="text-gray-400 font-medium">TD Ameritrade</span>
              <span className="text-gray-400 font-medium">Interactive Brokers</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;