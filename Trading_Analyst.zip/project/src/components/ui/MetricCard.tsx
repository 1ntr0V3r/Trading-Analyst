import React from 'react';

interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down';
  icon: React.ReactNode;
  color: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  title, 
  value, 
  change, 
  trend, 
  icon,
  color = 'accent-blue'
}) => {
  return (
    <div className="bg-background-tertiary/50 rounded-lg p-5 border border-gray-800 hover:border-gray-700 transition">
      <div className="flex justify-between items-start mb-3">
        <h4 className="text-gray-400 text-sm font-medium">{title}</h4>
        <div className={`p-2 rounded-lg bg-${color}/20`}>
          {icon}
        </div>
      </div>
      <div className="flex flex-col">
        <span className="text-2xl font-bold mb-1">{value}</span>
        <div className={`text-sm ${trend === 'up' ? 'text-status-success' : 'text-status-error'} flex items-center`}>
          {change}
          <span className="ml-1">
            {trend === 'up' ? '↑' : '↓'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default MetricCard;