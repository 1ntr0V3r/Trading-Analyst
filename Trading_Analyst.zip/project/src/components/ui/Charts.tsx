import React from 'react';

export const AreaChart = () => {
  return (
    <div className="w-full h-64 relative">
      {/* SVG Chart simulation */}
      <svg className="w-full h-full" viewBox="0 0 600 200">
        {/* Grid lines */}
        {[...Array(6)].map((_, i) => (
          <line 
            key={`gridline-${i}`}
            x1="0" 
            y1={i * 40} 
            x2="600" 
            y2={i * 40} 
            stroke="rgba(255,255,255,0.1)" 
            strokeDasharray="4,4"
          />
        ))}
        
        {/* Time labels */}
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => (
          <text 
            key={`day-${i}`}
            x={i * (600/6) + 10} 
            y="195" 
            fill="rgba(255,255,255,0.5)"
            fontSize="10"
          >
            {day}
          </text>
        ))}
        
        {/* Area Chart */}
        <defs>
          <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="rgba(0,200,255,0.6)" />
            <stop offset="100%" stopColor="rgba(0,200,255,0)" />
          </linearGradient>
        </defs>
        
        {/* Main path */}
        <path 
          d="M0,160 C40,150 80,100 120,90 C160,80 200,110 240,100 C280,90 320,40 360,30 C400,20 440,50 480,40 C520,30 560,10 600,20" 
          fill="none" 
          stroke="#00C8FF" 
          strokeWidth="2"
        />
        
        {/* Fill area */}
        <path 
          d="M0,160 C40,150 80,100 120,90 C160,80 200,110 240,100 C280,90 320,40 360,30 C400,20 440,50 480,40 C520,30 560,10 600,20 L600,200 L0,200 Z" 
          fill="url(#areaGradient)"
          opacity="0.5"
        />
        
        {/* Data points */}
        {[
          [0, 160], [100, 90], [200, 110], [300, 40], [400, 50], [500, 10], [600, 20]
        ].map(([x, y], i) => (
          <circle 
            key={`point-${i}`}
            cx={x} 
            cy={y} 
            r="4" 
            fill="#00C8FF"
          />
        ))}
      </svg>
      
      {/* Interactive dots */}
      <div className="absolute top-1/3 left-1/2 w-2 h-2 bg-accent-blue rounded-full animate-pulse"></div>
      <div className="absolute top-1/4 left-3/4 w-2 h-2 bg-accent-green rounded-full animate-pulse"></div>
    </div>
  );
};

export const BarChart = () => {
  const bars = [
    { height: 60, color: '#00E676' },
    { height: 40, color: '#00E676' },
    { height: 80, color: '#00E676' },
    { height: 30, color: '#FF3D71' },
    { height: 50, color: '#00E676' },
    { height: 90, color: '#00E676' },
    { height: 20, color: '#FF3D71' },
    { height: 70, color: '#00E676' },
    { height: 45, color: '#00E676' },
    { height: 65, color: '#00E676' },
    { height: 35, color: '#FF3D71' },
    { height: 55, color: '#00E676' },
  ];

  return (
    <div className="w-full h-48 flex items-end justify-between px-2">
      {bars.map((bar, index) => (
        <div 
          key={index}
          className="w-6 rounded-t-sm transition-all duration-500 ease-out hover:opacity-80"
          style={{ 
            height: `${bar.height}%`, 
            backgroundColor: bar.color 
          }}
        ></div>
      ))}
    </div>
  );
};

export const PieChart = () => {
  return (
    <div className="w-full h-48 flex items-center justify-center">
      <svg width="160" height="160" viewBox="0 0 160 160">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        {/* Pie Chart segments */}
        <circle cx="80" cy="80" r="70" fill="transparent" stroke="#333" strokeWidth="1" />
        
        {/* Segment 1 - 45% */}
        <path 
          d="M80,80 L80,10 A70,70 0 0,1 142,115 z" 
          fill="#00C8FF"
          filter="url(#glow)"
        />
        
        {/* Segment 2 - 30% */}
        <path 
          d="M80,80 L142,115 A70,70 0 0,1 45,138 z" 
          fill="#39FF14"
          filter="url(#glow)"
        />
        
        {/* Segment 3 - 25% */}
        <path 
          d="M80,80 L45,138 A70,70 0 0,1 10,65 z" 
          fill="#B026FF"
          filter="url(#glow)"
        />
        
        {/* Segment 4 - 15% */}
        <path 
          d="M80,80 L10,65 A70,70 0 0,1 80,10 z" 
          fill="#FF3D71"
          filter="url(#glow)"
        />
        
        {/* Center circle */}
        <circle cx="80" cy="80" r="40" fill="#121827" />
        
        {/* Text in center */}
        <text x="80" y="75" textAnchor="middle" fill="white" fontSize="16" fontWeight="bold">129</text>
        <text x="80" y="95" textAnchor="middle" fill="#888" fontSize="12">Trades</text>
      </svg>
      
      {/* Legend */}
      <div className="grid grid-cols-2 gap-x-4 gap-y-2 ml-4 text-xs">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-accent-blue rounded-sm mr-2"></div>
          <span>Long (45%)</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-accent-green rounded-sm mr-2"></div>
          <span>Short (30%)</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-accent-purple rounded-sm mr-2"></div>
          <span>Swing (25%)</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 bg-status-error rounded-sm mr-2"></div>
          <span>Scalp (15%)</span>
        </div>
      </div>
    </div>
  );
};

export const Table = () => {
  const data = [
    { id: 1, type: 'Buy', symbol: 'AAPL', entry: '$182.63', exit: '$189.25', pnl: '+$654.32', date: '2025-06-10' },
    { id: 2, type: 'Sell', symbol: 'TSLA', entry: '$254.87', exit: '$245.63', pnl: '+$921.18', date: '2025-06-09' },
    { id: 3, type: 'Buy', symbol: 'MSFT', entry: '$412.36', exit: '$409.58', pnl: '-$278.00', date: '2025-06-08' },
    { id: 4, type: 'Sell', symbol: 'AMZN', entry: '$178.92', exit: '$173.45', pnl: '+$547.00', date: '2025-06-07' },
    { id: 5, type: 'Buy', symbol: 'NVDA', entry: '$118.73', exit: '$124.92', pnl: '+$618.45', date: '2025-06-06' },
  ];

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="border-b border-gray-700 text-left text-gray-400">
            <th className="pb-3 font-medium">Type</th>
            <th className="pb-3 font-medium">Symbol</th>
            <th className="pb-3 font-medium">Entry</th>
            <th className="pb-3 font-medium">Exit</th>
            <th className="pb-3 font-medium">P&L</th>
            <th className="pb-3 font-medium">Date</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row.id} className="border-b border-gray-800/50 hover:bg-background-secondary transition">
              <td className="py-3">
                <span className={`inline-block px-2 py-1 rounded text-xs ${
                  row.type === 'Buy' ? 'bg-accent-green/20 text-accent-green' : 'bg-accent-purple/20 text-accent-purple'
                }`}>
                  {row.type}
                </span>
              </td>
              <td className="py-3 font-mono">{row.symbol}</td>
              <td className="py-3 font-mono">{row.entry}</td>
              <td className="py-3 font-mono">{row.exit}</td>
              <td className={`py-3 font-mono ${
                row.pnl.startsWith('+') ? 'text-status-success' : 'text-status-error'
              }`}>
                {row.pnl}
              </td>
              <td className="py-3 text-gray-400">{row.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};