import React from 'react';

interface InsightCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

const InsightCard: React.FC<InsightCardProps> = ({ 
  title, 
  description, 
  icon,
  color = 'status-warning'
}) => {
  return (
    <div className="bg-background-tertiary/50 rounded-lg p-5 border border-gray-800 hover:border-gray-700 transition h-full">
      <div className={`p-2 inline-block rounded-lg bg-${color}/20 mb-4`}>
        {icon}
      </div>
      <h4 className="text-lg font-medium mb-2">{title}</h4>
      <p className="text-gray-400">{description}</p>
      <button className="mt-4 text-accent-blue hover:text-accent-blue/90 text-sm font-medium flex items-center">
        Learn more
        <svg className="w-4 h-4 ml-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      </button>
    </div>
  );
};

export default InsightCard;