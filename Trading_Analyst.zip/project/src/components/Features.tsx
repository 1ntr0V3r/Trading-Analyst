import React from 'react';
import { TrendingUp, BarChart2, FileText, LineChart, Zap, CheckCircle, Repeat, Lock } from 'lucide-react';

const Features = () => {
  const features = [
    {
      icon: <TrendingUp className="h-6 w-6" />,
      title: 'Performance Tracking',
      description: 'Track your win rates, profit/loss, and performance metrics over time.',
      color: 'accent-blue'
    },
    {
      icon: <BarChart2 className="h-6 w-6" />,
      title: 'Pattern Recognition',
      description: 'Identify recurring patterns in your trading behavior and market conditions.',
      color: 'accent-green'
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: 'Trade Journaling',
      description: 'Keep detailed notes on your trades with automated tagging and categorization.',
      color: 'accent-purple'
    },
    {
      icon: <LineChart className="h-6 w-6" />,
      title: 'Advanced Analytics',
      description: 'Visualize your trading data with interactive charts and custom metrics.',
      color: 'status-success'
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: 'AI-Powered Insights',
      description: 'Get personalized suggestions to improve your trading strategy.',
      color: 'status-warning'
    },
    {
      icon: <CheckCircle className="h-6 w-6" />,
      title: 'Strategy Validation',
      description: 'Validate your trading strategies against historical data.',
      color: 'accent-blue'
    },
    {
      icon: <Repeat className="h-6 w-6" />,
      title: 'Multi-platform Sync',
      description: 'Sync your trading data from multiple platforms and brokerages.',
      color: 'accent-green'
    },
    {
      icon: <Lock className="h-6 w-6" />,
      title: 'Secure Data Storage',
      description: 'Your trading data is encrypted and securely stored with bank-level security.',
      color: 'accent-purple'
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Features For Every Trader</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Our platform provides everything you need to analyze and improve your trading performance
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-background-secondary/50 backdrop-blur-sm rounded-lg p-6 border border-gray-800 hover:border-gray-700 transition group"
            >
              <div className={`p-3 rounded-lg bg-${feature.color}/20 mb-5 inline-block group-hover:bg-${feature.color}/30 transition`}>
                <div className={`text-${feature.color}`}>
                  {feature.icon}
                </div>
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <h3 className="text-2xl font-bold mb-8">Ready to Transform Your Trading?</h3>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="w-full sm:w-auto bg-accent-blue hover:bg-accent-blue/90 text-gray-900 font-medium px-8 py-4 rounded-lg transition shadow-[0_0_15px_rgba(0,200,255,0.5)]">
              Start Your Free Trial
            </button>
            <button className="w-full sm:w-auto bg-transparent border border-gray-700 hover:border-gray-500 text-white px-8 py-4 rounded-lg transition">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;