import React from 'react';
import { AreaChart, BarChart, PieChart, Table } from './ui/Charts';
import MetricCard from './ui/MetricCard';
import InsightCard from './ui/InsightCard';
import { ArrowUpRight, ArrowDownRight, TrendingUp, Clock, AlertTriangle, Award } from 'lucide-react';

const Dashboard = () => {
  return (
    <section className="py-16 bg-background-primary/50 backdrop-blur-md">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Powerful Analytics Dashboard</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Visualize your trading performance with comprehensive analytics and actionable insights
          </p>
        </div>

        <div className="relative rounded-xl border border-gray-800 bg-background-secondary/50 backdrop-blur-md p-5 md:p-8 shadow-xl overflow-hidden">
          {/* Glow effect */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-accent-blue/20 to-accent-purple/20 rounded-xl blur opacity-30"></div>
          
          <div className="relative z-10">
            {/* Dashboard header */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
              <div>
                <h3 className="text-xl font-bold">Portfolio Performance</h3>
                <p className="text-gray-400">Last 30 days</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <button className="bg-background-tertiary px-3 py-1.5 rounded-md text-sm hover:bg-gray-800 transition">1D</button>
                <button className="bg-accent-blue/20 px-3 py-1.5 rounded-md text-sm text-accent-blue border border-accent-blue/30">1W</button>
                <button className="bg-background-tertiary px-3 py-1.5 rounded-md text-sm hover:bg-gray-800 transition">1M</button>
                <button className="bg-background-tertiary px-3 py-1.5 rounded-md text-sm hover:bg-gray-800 transition">3M</button>
                <button className="bg-background-tertiary px-3 py-1.5 rounded-md text-sm hover:bg-gray-800 transition">1Y</button>
                <button className="bg-background-tertiary px-3 py-1.5 rounded-md text-sm hover:bg-gray-800 transition">All</button>
              </div>
            </div>

            {/* Metrics cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
              <MetricCard 
                title="Total Profit/Loss" 
                value="$7,842.50" 
                change="+12.3%"
                trend="up"
                icon={<ArrowUpRight className="w-5 h-5" />}
                color="accent-green"
              />
              <MetricCard 
                title="Win Rate" 
                value="68.5%" 
                change="+4.2%"
                trend="up"
                icon={<TrendingUp className="w-5 h-5" />}
                color="accent-blue"
              />
              <MetricCard 
                title="Total Trades" 
                value="129" 
                change="-5.1%"
                trend="down"
                icon={<Clock className="w-5 h-5" />}
                color="accent-purple"
              />
              <MetricCard 
                title="Avg. Return" 
                value="$183.45" 
                change="-2.3%"
                trend="down"
                icon={<ArrowDownRight className="w-5 h-5" />}
                color="status-warning"
              />
            </div>

            {/* Charts section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 mb-8">
              <div className="lg:col-span-2 bg-background-tertiary/50 rounded-lg p-5 border border-gray-800">
                <h4 className="font-medium mb-4">Performance Over Time</h4>
                <AreaChart />
              </div>
              <div className="bg-background-tertiary/50 rounded-lg p-5 border border-gray-800">
                <h4 className="font-medium mb-4">Trade Type Distribution</h4>
                <PieChart />
              </div>
            </div>

            {/* Bottom section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              <div className="lg:col-span-2 bg-background-tertiary/50 rounded-lg p-5 border border-gray-800">
                <h4 className="font-medium mb-4">Recent Trades</h4>
                <Table />
              </div>
              <div className="flex flex-col gap-5">
                <InsightCard 
                  title="Most Common Mistake"
                  description="Early exit from winning trades"
                  icon={<AlertTriangle className="w-5 h-5 text-status-warning" />}
                  color="status-warning"
                />
                <InsightCard 
                  title="Best Performing Strategy"
                  description="Momentum breakouts on 4H timeframe"
                  icon={<Award className="w-5 h-5 text-status-success" />}
                  color="status-success"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;