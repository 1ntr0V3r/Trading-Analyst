import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Dashboard from './components/Dashboard';
import Features from './components/Features';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 to-blue-950 text-gray-100">
      <Header />
      <main>
        <Hero />
        <Dashboard />
        <Features />
      </main>
      <Footer />
    </div>
  );
}

export default App;